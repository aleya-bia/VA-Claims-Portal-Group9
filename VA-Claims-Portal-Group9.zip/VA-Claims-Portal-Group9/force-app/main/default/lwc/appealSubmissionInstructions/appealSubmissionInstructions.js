import { LightningElement } from 'lwc';

export default class AppealSubmissionInstructions extends LightningElement {}