declare module "@salesforce/resourceUrl/CourseCertificateImage" {
    var CourseCertificateImage: string;
    export default CourseCertificateImage;
}