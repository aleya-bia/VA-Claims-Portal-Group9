declare module "@salesforce/apex/DynamicObjectSearchController.getObjectFields" {
  export default function getObjectFields(param: {objectName: any}): Promise<any>;
}
declare module "@salesforce/apex/DynamicObjectSearchController.getRecords" {
  export default function getRecords(param: {objectName: any, fieldNames: any}): Promise<any>;
}
