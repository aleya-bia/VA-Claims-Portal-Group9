declare module "@salesforce/resourceUrl/TestCourseAttendees" {
    var TestCourseAttendees: string;
    export default TestCourseAttendees;
}