import { LightningElement } from 'lwc';

export default class HomePage extends LightningElement {}