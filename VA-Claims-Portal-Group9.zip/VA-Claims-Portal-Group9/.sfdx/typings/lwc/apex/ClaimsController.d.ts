declare module "@salesforce/apex/ClaimsController.getOpenClaims" {
  export default function getOpenClaims(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsController.getClosedClaims" {
  export default function getClosedClaims(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsController.getClaimStatusCounts" {
  export default function getClaimStatusCounts(): Promise<any>;
}
