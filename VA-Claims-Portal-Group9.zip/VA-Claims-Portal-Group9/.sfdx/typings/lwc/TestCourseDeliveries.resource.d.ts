declare module "@salesforce/resourceUrl/TestCourseDeliveries" {
    var TestCourseDeliveries: string;
    export default TestCourseDeliveries;
}