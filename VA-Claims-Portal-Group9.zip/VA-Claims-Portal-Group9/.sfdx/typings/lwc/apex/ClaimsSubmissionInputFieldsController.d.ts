declare module "@salesforce/apex/ClaimsSubmissionInputFieldsController.createClaim" {
  export default function createClaim(param: {relData: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsSubmissionInputFieldsController.associateFilesWithClaimApex" {
  export default function associateFilesWithClaimApex(param: {contentDocumentLinks: any}): Promise<any>;
}
