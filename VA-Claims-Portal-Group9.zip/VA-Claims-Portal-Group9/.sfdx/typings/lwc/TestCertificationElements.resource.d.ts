declare module "@salesforce/resourceUrl/TestCertificationElements" {
    var TestCertificationElements: string;
    export default TestCertificationElements;
}