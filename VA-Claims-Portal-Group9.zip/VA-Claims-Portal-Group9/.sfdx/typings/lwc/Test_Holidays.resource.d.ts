declare module "@salesforce/resourceUrl/Test_Holidays" {
    var Test_Holidays: string;
    export default Test_Holidays;
}