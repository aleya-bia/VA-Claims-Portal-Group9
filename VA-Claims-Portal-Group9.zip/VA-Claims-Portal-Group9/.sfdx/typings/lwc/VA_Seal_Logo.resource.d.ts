declare module "@salesforce/resourceUrl/VA_Seal_Logo" {
    var VA_Seal_Logo: string;
    export default VA_Seal_Logo;
}