declare module "@salesforce/apex/CertCheckerController.getCertsHeld" {
  export default function getCertsHeld(param: {acctId: any}): Promise<any>;
}
declare module "@salesforce/apex/CertCheckerController.getTechniciansAttendance" {
  export default function getTechniciansAttendance(param: {techIds: any}): Promise<any>;
}
declare module "@salesforce/apex/CertCheckerController.getTechniciansCertAttempts" {
  export default function getTechniciansCertAttempts(param: {techIds: any}): Promise<any>;
}
declare module "@salesforce/apex/CertCheckerController.deleteCertsHeld" {
  export default function deleteCertsHeld(param: {certIds: any}): Promise<any>;
}
