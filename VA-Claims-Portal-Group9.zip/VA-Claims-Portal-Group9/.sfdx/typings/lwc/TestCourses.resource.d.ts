declare module "@salesforce/resourceUrl/TestCourses" {
    var TestCourses: string;
    export default TestCourses;
}