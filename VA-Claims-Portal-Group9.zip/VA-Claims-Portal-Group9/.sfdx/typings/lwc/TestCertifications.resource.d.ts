declare module "@salesforce/resourceUrl/TestCertifications" {
    var TestCertifications: string;
    export default TestCertifications;
}