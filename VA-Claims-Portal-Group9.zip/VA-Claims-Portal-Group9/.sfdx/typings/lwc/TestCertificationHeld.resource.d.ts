declare module "@salesforce/resourceUrl/TestCertificationHeld" {
    var TestCertificationHeld: string;
    export default TestCertificationHeld;
}