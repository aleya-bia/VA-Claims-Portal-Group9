declare module "@salesforce/resourceUrl/SNA_9qFw3_sf_default_cdn_Veteran_Tracking_User_Portal1" {
    var SNA_9qFw3_sf_default_cdn_Veteran_Tracking_User_Portal1: string;
    export default SNA_9qFw3_sf_default_cdn_Veteran_Tracking_User_Portal1;
}