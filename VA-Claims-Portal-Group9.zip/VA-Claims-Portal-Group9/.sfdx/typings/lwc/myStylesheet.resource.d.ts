declare module "@salesforce/resourceUrl/myStylesheet" {
    var myStylesheet: string;
    export default myStylesheet;
}