declare module "@salesforce/resourceUrl/TestContacts" {
    var TestContacts: string;
    export default TestContacts;
}