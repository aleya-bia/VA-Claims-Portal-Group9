declare module "@salesforce/apex/AppealsController.getOpenAppeals" {
  export default function getOpenAppeals(): Promise<any>;
}
declare module "@salesforce/apex/AppealsController.getClosedAppeals" {
  export default function getClosedAppeals(): Promise<any>;
}
