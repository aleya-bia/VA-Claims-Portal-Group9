declare module "@salesforce/resourceUrl/TestAccounts" {
    var TestAccounts: string;
    export default TestAccounts;
}