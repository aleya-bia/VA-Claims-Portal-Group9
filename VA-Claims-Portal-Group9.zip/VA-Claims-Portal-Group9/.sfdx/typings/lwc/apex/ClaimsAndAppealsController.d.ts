declare module "@salesforce/apex/ClaimsAndAppealsController.getClaimsAndAppealsOverview" {
  export default function getClaimsAndAppealsOverview(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsAndAppealsController.getLoggedInVeteranAccountId" {
  export default function getLoggedInVeteranAccountId(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsAndAppealsController.getVeteranClaims" {
  export default function getVeteranClaims(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsAndAppealsController.getClaimDetails" {
  export default function getClaimDetails(param: {claimId: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsAndAppealsController.getVeteranAppeals" {
  export default function getVeteranAppeals(): Promise<any>;
}
declare module "@salesforce/apex/ClaimsAndAppealsController.getAppealDetails" {
  export default function getAppealDetails(param: {appealId: any}): Promise<any>;
}
declare module "@salesforce/apex/ClaimsAndAppealsController.getFiles" {
  export default function getFiles(param: {recordId: any}): Promise<any>;
}
