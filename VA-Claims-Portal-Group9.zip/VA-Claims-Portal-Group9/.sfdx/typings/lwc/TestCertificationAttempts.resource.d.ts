declare module "@salesforce/resourceUrl/TestCertificationAttempts" {
    var TestCertificationAttempts: string;
    export default TestCertificationAttempts;
}