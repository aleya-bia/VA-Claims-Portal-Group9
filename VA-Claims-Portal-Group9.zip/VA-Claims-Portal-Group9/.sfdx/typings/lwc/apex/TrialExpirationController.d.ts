declare module "@salesforce/apex/TrialExpirationController.getExpirationDaysLeft" {
  export default function getExpirationDaysLeft(): Promise<any>;
}
